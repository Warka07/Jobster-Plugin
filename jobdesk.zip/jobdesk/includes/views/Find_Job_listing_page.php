<div class="col-lg-7 col-xl-8 col-xxl-9 ">
   <div class="pxp-jobs-list-top mt-4 mt-lg-0">
      <div class="row justify-content-between align-items-center">
         <div class="col-auto">
            <h2>
               <span class="pxp-text-light">Showing</span> 
               16 
               <span class="pxp-text-light">jobs</span>
            </h2>
         </div>
         <div class="col-auto">
            <select class="form-select" id="pxp-sort-jobs">
               <option value="newest" selected="selected">
                  Newest                                
               </option>
               <option value="oldest">
                  Oldest                                
               </option>
            </select>
         </div>
      </div>
   </div>
   <div class="row">
      <div class="col-md-6 col-lg-12 col-xl-6 col-xxl-4 pxp-jobs-card-1-container">
         <div class="pxp-jobs-card-1 pxp-has-border">
            <div class="pxp-jobs-card-1-top">
               <a href="https://pixelprime.co/themes/jobster-wp/demo-1/jobs-list/?category=24" class="pxp-jobs-card-1-category">
                  <div class="pxp-jobs-card-1-category-icon">
                     <span class="fa fa-cubes"></span>
                  </div>
                  <div class="pxp-jobs-card-1-category-label">
                     Construction                                                    
                  </div>
               </a>
               <a href="https://pixelprime.co/themes/jobster-wp/demo-1/jobs/agiota/" class="pxp-jobs-card-1-title">
               Agiota                                            </a>
               <div class="pxp-jobs-card-1-details">
                  <a href="https://pixelprime.co/themes/jobster-wp/demo-1/jobs-list/?location=16" class="pxp-jobs-card-1-location">
                  <span class="fa fa-globe"></span>
                  Chicago, IL                                                    </a>
                  <div class="pxp-jobs-card-1-type">
                     Contract                                                    
                  </div>
               </div>
            </div>
            <div class="pxp-jobs-card-1-bottom">
               <div class="pxp-jobs-card-1-bottom-left">
                  <div class="pxp-jobs-card-1-date pxp-text-light">
                     October 30, 2022                                                        <span class="d-inline">
                     by                                                        </span>
                  </div>
                  <a href="https://pixelprime.co/themes/jobster-wp/demo-1/companies/farlindo/" class="pxp-jobs-card-1-company">
                  Farlindo                                                    </a>
               </div>
               <a href="https://pixelprime.co/themes/jobster-wp/demo-1/companies/farlindo/" class="pxp-jobs-card-1-company-logo pxp-no-img">
               F                                                    </a>
            </div>
         </div>
      </div>

   <div class="row mt-4 mt-lg-5 justify-content-between align-items-center">
      <div class="col-auto">
         <nav class="mt-3 mt-sm-0" aria-label="Pagination">
            <ul class="pagination pxp-pagination">
               <li class="page-item active">
                  <a class="page-link" href="#">
                  1                                            </a>
               </li>
               <li class="page-item">
                  <a class="page-link" href="https://pixelprime.co/themes/jobster-wp/demo-1/jobs-list/page/2/">
                  2                                            </a>
               </li>
            </ul>
         </nav>
      </div>
      <div class="col-auto pxp-next-page-link mt-3 mt-sm-0">
         <a href="https://pixelprime.co/themes/jobster-wp/demo-1/jobs-list/page/2/">
            <div class="btn rounded-pill pxp-section-cta">Show me more<span class="fa fa-angle-right"></span>
            </div>
         </a>
      </div>
   </div>
</div>